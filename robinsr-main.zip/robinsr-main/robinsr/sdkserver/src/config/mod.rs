mod version_config;

pub use version_config::INSTANCE as versions;
